
from collections import deque
import heapq
import math

class Graph:
    def __init__(self):
        self.adj = {}
        self.coords = {}

    def add_edge(self, u, v, w):
        self.adj.setdefault(u, []).append((v, w))
        self.adj.setdefault(v, []).append((u, w))

    def set_coord(self, node, x, y):
        self.coords[node] = (x, y)

    def neighbors(self, node):
        return self.adj.get(node, [])

    def distance(self, u, v):
        for n, d in self.neighbors(u):
            if n == v:
                return d
        return math.inf

def bfs(graph, start, goal):
    q = deque([start])
    visited = {start: None}
    while q:
        node = q.popleft()
        if node == goal:
            break
        for neigh, _ in graph.neighbors(node):
            if neigh not in visited:
                visited[neigh] = node
                q.append(neigh)
    return reconstruct_path(visited, start, goal)

def dfs(graph, start, goal):
    stack = [(start, [start])]
    while stack:
        node, path = stack.pop()
        if node == goal:
            return path
        for neigh, _ in graph.neighbors(node):
            if neigh not in path:
                stack.append((neigh, path + [neigh]))
    return []

def ucs(graph, start, goal):
    pq = [(0, start)]
    cost = {start: 0}
    parent = {start: None}
    while pq:
        c, node = heapq.heappop(pq)
        if node == goal:
            break
        for neigh, w in graph.neighbors(node):
            new_c = c + w
            if neigh not in cost or new_c < cost[neigh]:
                cost[neigh] = new_c
                parent[neigh] = node
                heapq.heappush(pq, (new_c, neigh))
    return reconstruct_path(parent, start, goal)

def heuristic(graph, a, b):
    if a not in graph.coords or b not in graph.coords:
        return 0
    x1, y1 = graph.coords[a]
    x2, y2 = graph.coords[b]
    return math.hypot(x1 - x2, y1 - y2)

def astar(graph, start, goal):
    pq = [(0, start)]
    g = {start: 0}
    parent = {start: None}
    while pq:
        _, node = heapq.heappop(pq)
        if node == goal:
            break
        for neigh, w in graph.neighbors(node):
            new_g = g[node] + w
            if neigh not in g or new_g < g[neigh]:
                g[neigh] = new_g
                f = new_g + heuristic(graph, neigh, goal)
                parent[neigh] = node
                heapq.heappush(pq, (f, neigh))
    return reconstruct_path(parent, start, goal)

def reconstruct_path(parent, start, goal):
    path = []
    cur = goal
    while cur is not None:
        path.append(cur)
        cur = parent.get(cur)
    return list(reversed(path)) if path and path[-1] == start else []
