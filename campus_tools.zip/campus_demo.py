
from graph_ai import Graph, bfs, dfs, ucs, astar

def build_campus():
    g = Graph()
    g.add_edge("Main Gate", "ID Gate", 170)
    g.add_edge("ID Gate", "Library", 70)
    g.add_edge("ID Gate", "ACB1-LW", 100)
    g.add_edge("ACB1-LW", "Cafe", 170)
    g.add_edge("Cafe", "AC2", 140)
    g.add_edge("Library", "AC2", 150)
    g.add_edge("AC2", "Food Court", 200)
    g.add_edge("Food Court", "Hostel", 150)
    g.add_edge("Hostel", "Sports Complex", 450)
    g.set_coord("Main Gate", 0, 0)
    g.set_coord("ID Gate", 50, 0)
    g.set_coord("Library", 100, 0)
    g.set_coord("ACB1-LW", 50, 40)
    g.set_coord("Cafe", 100, 40)
    g.set_coord("AC2", 140, 20)
    g.set_coord("Food Court", 180, 20)
    g.set_coord("Hostel", 230, 20)
    g.set_coord("Sports Complex", 300, 20)
    return g

if __name__ == "__main__":
    campus = build_campus()
    print("BFS Hostel → Library:", bfs(campus, "Hostel", "Library"))
    print("DFS Hostel → Library:", dfs(campus, "Hostel", "Library"))
    print("UCS Hostel → Library:", ucs(campus, "Hostel", "Library"))
    print("A* Hostel → Library:", astar(campus, "Hostel", "Library"))
