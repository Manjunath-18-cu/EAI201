
from campus_demo import build_campus
from graph_ai import bfs, ucs, astar

campus = build_campus()

def chatbot():
    print("Hello! I am your Campus Chatbot")
    print("I can help with FAQs and directions.")
    while True:
        msg = input("You: ").lower()
        if "bye" in msg:
            print("Bot: Goodbye!")
            break
        elif "hod" in msg:
            print("Bot: The HOD of CSE is Dr. XYZ.")
        elif "library" in msg and "hostel" in msg:
            path = astar(campus, "Hostel", "Library")
            print("Bot: Shortest path Hostel → Library is:", " → ".join(path))
        else:
            print("Bot: Sorry, I can only answer basic FAQs or directions now.")

if __name__ == "__main__":
    chatbot()
